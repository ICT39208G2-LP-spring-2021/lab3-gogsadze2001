<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'gtu';
?>
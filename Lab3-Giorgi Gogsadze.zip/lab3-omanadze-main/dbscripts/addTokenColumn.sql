ALTER TABLE users
ADD EmailVerificationToken VARCHAR(32) NOT NULL DEFAULT 'token'